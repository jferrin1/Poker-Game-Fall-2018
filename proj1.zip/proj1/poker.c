#include "poker.h"

int main() {
  Player p1 = {0};
  Player p2 = {0};
  Player p3 = {0};
  void getcards();
}

//parse in cards from a text file and store them
void getcards(){
  FILE *fp;
  char *line = NULL
  size_t bufSize= 32;
  ssize_t len;
  fp = fopen("sample_hands.txt", "r");
  if(fp==NULL) printf("%s", "cannot open file");
    if(getline(&line, &bufSize, fp)!=-1){
      printf("%s", line);
    }
}

//comparator function for qsort
int compareCards(const void *v, const void *w){
	int x = ((Player *)v)->hand->val;
	int y = ((Player *)w)->hand->val;
	return (x-y);
}

//sort the cards in the hand array numerically
void sortCards(Player p){
  qsort(p.hand, 7, 2, compareCards);
}

//check to see if/how many pairs are in a hand
int ckpairs(Player p){
  int pairs=0;//number of pairs in the players hand
  int i=0; //for loop counter
  for(; i<4; i++){
    if(p.hand[i].val==p.hand[i+1].val) pairs++;// increment pairs when val hand[i]==val hand[i]
  }return pairs;//return number of pairs in the players hand
}

//check to see if a hand contains a Flush
int ckflush(Player p){
  int i=0;//for loop counter
  int r=0;//condition occurance counter
  for(; i<4; i++){
    if(p.hand[i].suit==p.hand[i+1].suit) r++;
  }
  if(r=5) return 1;//1==True
  return 0;//0==False
}

//check to see if a hand contains a Straight
int ckstraight(Player p){
  int i=0; //for loop counter
  int r=0; //condition occurance counter
  for(; i<4; i++){
    if(p.hand[i+1].val-p.hand[i].val) r++; //increment r when hand[i+1] is 1 more than hand[i]
    }
    if(r=5) return 1; else return 0;
}

/*
//check to see if a hand contains a full
int ckfull(Player p){

}


//check to see if a hand contains a 3oak
int ck3oak(Player p){
  if(int pairs==3) return 1; else return 0;
}

//check to see if a hand contains a 4oak
int ck4oak(Player p){
  if(int pairs==4)
}

//check to see if a hand contains a straight flush or royal flush
int ckstrflush(Player p){

}
*/
