#include <stdio.h>
#include <stdlib.h>
char* draw={"a"};

enum suit{S,C,D,H}sut;
enum face{T,J,Q,K,A}fac;
//A structure that makes a card object that contains an int val and an int suit
typedef struct card{
  int val;
  int suit;
}Card;

//A structure that makes a player object that contains an array of 7 cards named hand
typedef struct player{
  Card hand[7];
}Player;

void main()
void sortCards(Player p)
void ckpairs(Player p)
void ckstraight(Player p)
void ckflush(Player p)
